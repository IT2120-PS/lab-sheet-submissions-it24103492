setwd("C:\\Users\\DELL\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop")
observed <- c(120, 95, 85, 100)
expected_prob <- c(0.25, 0.25, 0.25, 0.25)
chisq_result <- chisq.test(x = observed, p = expected_prob)
chisq_result
chisq_result$expected   
chisq_result$observed   
chisq_result$statistic  
chisq_result$p.value   
if (chisq_result$p.value < 0.05) {
  cat
} else {
  cat
}
