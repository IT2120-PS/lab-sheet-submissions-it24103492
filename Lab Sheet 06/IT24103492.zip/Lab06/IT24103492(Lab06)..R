setwd("C:\\Users\\DELL\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\Lab06")
# 01-i
# X follows a Binomial distribution with n = 50 and p = 0.85

# 01-ii
n <- 50
p <- 0.85
probability <- pbinom(46, size = n, prob = p, lower.tail = FALSE)
probability


# 02-i
# X --> number of calls received in an hour

# 02-ii
# The distribution of X is Poisson with mean (lambda) = 12

# 02-iii
lambda <- 12
probability_1 <- dpois(15, lambda)
probability_1

