setwd("C:\\Users\\DELL\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop")

1)i)
set.seed(123) 
sample_baking <- rnorm(25, mean = 45, sd = 2)
sample_baking

ii)
t.test(sample_baking, mu = 46, alternative = "less", conf.level = 0.95)
